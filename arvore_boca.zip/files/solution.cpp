#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    cin >> n;
    int v[n+5][n+5];
    memset(v, 0, sizeof v);
    
    v[0][0]=1;
    int ans = 0;

    for(int i = 0; i < n; i++){
        for(int j = 0; j <= i; j++){
            if(v[i][j]){
                ans++;
                v[i+1][j]^=1;
                v[i+1][j+1]^=1;
            }
        }
    }

    cout << ans << endl;
}
