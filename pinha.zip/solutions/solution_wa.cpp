#include <bits/stdc++.h>

using namespace std;

const int MAXN = 505;

int main(){
    int n, m;
    cin >> n >> m;
    bitset<MAXN> bs[m];

    for(int i = 0; i < m; i++){
        string s;
        cin >> s;
        reverse(s.begin(), s.end());
        bs[i] = bitset<MAXN>(s);
        bs[i] >>= i;
    }

    for(int t = 0; t <= n; t++){
        bool ok = true;

        for(int i = 0; i < m; i++){
            if(t) bs[i] >>= 1;
            ok &= !(bs[i][0]);
        }

        if(ok){
            cout << (t+m+1) << endl;
            return 0;
        }
    }
}
