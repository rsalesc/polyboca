#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;

const int MAX_N = 500;
const int MAX_M = 10;
int n, m;
string strips[MAX_M];
char get_strip(const int time, const int strip, const int x) {
    //assert(0 <= strip && strip <= m);
    if (strip == m)
        return '0';
    const int real_x = x + time;
    if (real_x < 0 || real_x >= n)
        return '0';
    return strips[strip][real_x];
}

int main() {
    cin>>n>>m;
    //assert(4 <= n && n <= MAX_N);
    //assert(1 <= m && m <= MAX_M);

    for (int i = 0; i < m; ++i) {
        cin>>strips[i];
        //assert((int) strips[i].size() == n);
        //for (const char ch : strips[i])
            //assert(ch == '0' || ch == '1');
    }

    int ans = -1;
    for (int wait = 0; ; ++wait) {
        bool okay = true;
        int strip = -1;
        for (;;) {
            ++strip;
            if (strip == m)
                break;
            if (get_strip(wait+strip, strip, 0) == '1') {
                okay = false;
                break;
            }
            if (get_strip(wait+strip+1, strip, 0) == '1') {
                okay = false;
                break;
            }
        }
        if (okay) {
            ans = wait + m + 1;
            break;
        }
    }
    printf("%d\n", ans);
}
