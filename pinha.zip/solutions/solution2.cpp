#include <bits/stdc++.h>

using namespace std;

int main(){
    int n;
    int m;
    cin >> n >> m;

    string bs[m];
    for(int i = 0; i < m; i++){
        cin >> bs[i];
        bs[i] = bs[i].substr(i);
        while(bs[i].size() < n)
            bs[i] += '0';
    }

    for(int t = 0; t <= n; t++){
        string cur[m];
        for(int i = 0; i < m; i++){
            cur[i] = bs[i].substr(t);
            while(cur[i].size() < n)
                cur[i] += '0';
        }

        bool ok = true;
        for(int i = 0; i < m; i++){
            if(cur[i][0] == '1' || cur[i][1] == '1')
                ok = false;
        }

        if(ok){
            cout << (t+m+1) << endl;
            return 0;
        }
    }
}
