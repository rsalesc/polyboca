#include "testlib.h"
#include <iostream>

using namespace std;

int main(){
    registerValidation();

    int n = inf.readInt(4, 500, "n");
    inf.readSpace();
    int m = inf.readInt(1, 10, "m");
    inf.readEoln();

    for(int i = 0; i < m; i++){
        string s = inf.readWord("[0-1]+", "s_i");
        ensuref(s.size() == n, "binary string %d has not length n", i+1);
        inf.readEoln();
    }

    inf.readEof();
}
