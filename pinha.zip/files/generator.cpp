#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char * argv[]){
    registerGen(argc, argv, 1);
    int n = atoi(argv[1]);
    int m = atoi(argv[2]);
    int w = atoi(argv[3]);

    cout << n << " " << m << endl;
    for(int i = 0; i < m; i++){
        int len = 0;
        int last[2] = {0, 0};
        for(int j = 0; j < n; j++){
            int weight = w;
            if(!last[1] && last[0]) weight -= 4;
            else if(last[1] && len <= min(8, n/3)) weight += 2;
            int x = rnd.wnext(0,1,weight);
            cout << x;
            last[0] = last[1];
            last[1] = x;
            if(x) len++;
            else len = 0;
        }
        cout << endl;
    }
}
